const mongoose=require('mongoose')


const movieSchema=mongoose.Schema({
    img:String,
    name:String,
    desc:String,
    category:String,
    price:Number
})





module.exports=mongoose.model('movie',movieSchema)