const Category = require('../models/category')
const Movie=require('../models/movie')

exports.movise=async(req,res)=>{
    const movieRecord=await Movie.find()
    const categoryRecord=await Category.find()
    res.render('admin/movie.ejs',{movieRecord,categoryRecord})
}

exports.addmovieform=async(req,res)=>{
    const categoryRecord=await Category.find()
    res.render('admin/addmovieform.ejs',{categoryRecord})
}

exports.addmovie=async(req,res)=>{
    const filename=req.file.filename
    const {name,desc,category,price}=req.body
    const record=new Movie({name:name,desc:desc,category:category,price:price,img:filename})
    //console.log(record)
    record.save()
    res.redirect('/admin/')
}

exports.moviseupdateform=async(req,res)=>{
    const id=req.params.id
    const record=await Movie.findById(id)
    res.render('admin/movieupdateform.ejs',{record})
}

exports.movieupdate=async(req,res)=>{
    const id=req.params.id  
    const {name,desc,category,price}=req.body
    if(req.file){
        const filename=req.file.filename
        await Movie.findByIdAndUpdate(id,{name:name,desc:desc,category:category,price:price,img:filename})
    }else{
        await Movie.findByIdAndUpdate(id,{name:name,desc:desc,category:category,price:price})   
    }
    res.redirect('/admin/')
}

exports.moviedelete=async(req,res)=>{
    const id=req.params.id
    await Movie.findByIdAndDelete(id)
    res.redirect('/admin/')
}




exports.movieRecord=async(req,res)=>{
    const movieRecord=await Movie.find()
    //console.log(movieRecord)
    res.render('index.ejs',{movieRecord})
}