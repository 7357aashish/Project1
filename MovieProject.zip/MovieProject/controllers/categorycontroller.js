const Category=require('../models/category')

exports.addcategoryform=(req,res)=>{
    res.render('admin/categoryform.ejs',{message:''})
}

exports.addcategory=(req,res)=>{
    const {category}=req.body
    const record=new Category({category:category})
    record.save()
    res.render('admin/categoryform.ejs',{message:'Category is Added'})
}

exports.allcategory=async(req,res)=>{
    const record=await Category.find()
    res.render('admin/allcategory.ejs',{record})
}