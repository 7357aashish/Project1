const router=require('express').Router()
const categoryc=require('../controllers/categorycontroller')
const moviec=require('../controllers/moviecontroller')



router.get('/',moviec.movieRecord)






module.exports=router