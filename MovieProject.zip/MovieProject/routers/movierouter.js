const router=require('express').Router()
const categoryc=require('../controllers/categorycontroller')
const moviec=require('../controllers/moviecontroller')
const upload=require('../helper/multer')


router.get('/addcategory',categoryc.addcategoryform)
router.post('/addcategory',categoryc.addcategory)
router.get('/allcategory',categoryc.allcategory)



router.get('/',moviec.movise)
router.get('/addmovieform',moviec.addmovieform)
router.post('/addmovieform',upload.single('img'),moviec.addmovie)
router.get('/movieupdate/:id',moviec.moviseupdateform)
router.get('/movieupdate/:id',moviec.moviseupdateform)
router.post('/movieupdate/:id',upload.single('img'),moviec.movieupdate)
router.get('/moviedelete/:id',moviec.moviedelete)








module.exports=router